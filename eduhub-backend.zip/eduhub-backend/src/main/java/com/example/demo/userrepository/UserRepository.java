package com.example.demo.userrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.userentity.User;


public interface UserRepository extends JpaRepository<User, Long> {

	 User findByUsername(String username);
	 User findByEmail(String email);
	 
}
