package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.userentity.User;
import com.example.demo.userservice.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;
    

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User registeredUser = userService.registerUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
    }   

    @PostMapping("/login")
    public ResponseEntity<User> loginUser(@RequestParam("username") String username, @RequestParam("password") String password) {
        User user = userService.loginUser(username, password);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
     @PostMapping("/reset-password")
     public ResponseEntity<String> resetpassword(@RequestParam("email") String email,
    		                                      @RequestParam("newPassword") String newPassword){
    	 boolean resetSuccessful = userService.resetPassword(email, newPassword);
    	 if(resetSuccessful) {
    		 return ResponseEntity.ok("Password Reset Successfully");
    	 }
    	 return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
     }
     
    
}


