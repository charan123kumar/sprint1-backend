package com.example.demo.userservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.userrepository.UserRepository;
import com.example.demo.userentity.User;

@Service

public class UserService {
  @Autowired
  private UserRepository  userrepository;
  
  @Autowired
  private PasswordEncoder passwordEncoder;
  
  public User registerUser(User user) {
	  user.setPassword(passwordEncoder.encode(user.getPassword()));
	  return userrepository.save(user);
  }
  public User loginUser(String username,String password) {
	  User user = userrepository.findByUsername(username);
	  if(user != null && passwordEncoder.matches(password,user.getPassword())) {
		  return user;
	  }
	return null;
  }
  public boolean resetPassword(String email,String newPassword) {
	  User user = userrepository.findByEmail(email);
	  if(user != null) {
		  user.setPassword(passwordEncoder.encode(newPassword));
		  userrepository.save(user);
		  return true;
	  }
	  return false;
	  
  }
}
